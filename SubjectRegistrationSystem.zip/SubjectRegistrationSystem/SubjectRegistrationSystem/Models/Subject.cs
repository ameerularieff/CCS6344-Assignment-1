﻿namespace SubjectRegistrationSystem.Models
{
    public class Subject
    {
        public int SubjectID { get; set; }
        public string SubjectCode { get; set; }
        public string SubjectName { get; set; }
        public int Credit { get; set; }
        public int AvailableSeats { get; set; }
    }
}
