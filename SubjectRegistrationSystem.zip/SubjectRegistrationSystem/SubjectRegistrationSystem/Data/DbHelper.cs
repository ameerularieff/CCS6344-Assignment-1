﻿using Microsoft.Data.SqlClient;

namespace SubjectRegistrationSystem.Data
{
    public class DbHelper
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor _httpContext;

        public DbHelper(IConfiguration configuration, IHttpContextAccessor httpContext)
        {
            _configuration = configuration;
            _httpContext = httpContext;
        }

        public SqlConnection GetConnection()
        {
            var conn = new SqlConnection(
                _configuration.GetConnectionString("DefaultConnection")
            );

            conn.Open();

            var session = _httpContext.HttpContext?.Session;
            if (session == null)
                return conn;

            using var cmd = new SqlCommand();
            cmd.Connection = conn;

            // STUDENT RLS CONTEXT
            int? studentId = session.GetInt32("StudentID");
            if (studentId != null)
            {
                cmd.CommandText =
                    "EXEC sp_set_session_context @key=N'StudentID', @value=@sid;";
                cmd.Parameters.AddWithValue("@sid", studentId.Value);
                cmd.ExecuteNonQuery();
                cmd.Parameters.Clear();
            }

            // ADMIN RLS BYPASS FLAG
            string role = session.GetString("Role");
            if (role == "Admin")
            {
                cmd.CommandText =
                    "EXEC sp_set_session_context @key=N'IsAdmin', @value=1;";
                cmd.ExecuteNonQuery();
            }

            return conn;
        }
    }
}
