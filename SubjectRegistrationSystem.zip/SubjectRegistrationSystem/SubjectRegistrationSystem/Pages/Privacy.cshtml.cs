﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SubjectRegistrationSystem.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }

}
