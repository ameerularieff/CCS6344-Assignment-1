﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using SubjectRegistrationSystem.Data;

namespace SubjectRegistrationSystem.Pages.Student
{
    public class MySubjectsModel : PageModel
    {
        private readonly DbHelper _db;

        public MySubjectsModel(DbHelper db)
        {
            _db = db;
        }

        public List<MySubjectVM> Subjects { get; set; } = new();

        public void OnGet()
        {
            // Student only
            if (HttpContext.Session.GetString("Role") != "Student")
            {
                Response.Redirect("/Login");
                return;
            }

            LoadSubjects();
        }

        public IActionResult OnPostDrop(int subjectId)
        {
            int studentId = GetStudentId();

            using SqlConnection conn = _db.GetConnection();
            using SqlTransaction tran = conn.BeginTransaction();

            try
            {
                // Delete registration
                using SqlCommand deleteCmd = new(
                    @"DELETE FROM Registrations
              WHERE StudentID = @StudentID AND SubjectID = @SubjectID",
                    conn, tran
                );
                deleteCmd.Parameters.AddWithValue("@StudentID", studentId);
                deleteCmd.Parameters.AddWithValue("@SubjectID", subjectId);

                int rowsAffected = deleteCmd.ExecuteNonQuery();

                // Safety check: only update seats if a row was actually deleted
                if (rowsAffected > 0)
                {
                    // Increment available seats
                    using SqlCommand updateCmd = new(
                        @"UPDATE Subjects
                  SET AvailableSeats = AvailableSeats + 1
                  WHERE SubjectID = @SubjectID",
                        conn, tran
                    );
                    updateCmd.Parameters.AddWithValue("@SubjectID", subjectId);
                    updateCmd.ExecuteNonQuery();
                }

                tran.Commit();

                TempData["Message"] = "Subject dropped successfully.";
                return RedirectToPage();
            }
            catch
            {
                tran.Rollback();
                throw;
            }
        }

        private void LoadSubjects()
        {
            int studentId = GetStudentId();

            using SqlConnection conn = _db.GetConnection();

            string sql = @"
                SELECT s.SubjectID, s.SubjectCode, s.SubjectName, s.Credit, r.RegistrationDate
                FROM Registrations r
                JOIN Subjects s ON r.SubjectID = s.SubjectID
                WHERE r.StudentID = @StudentID";

            using SqlCommand cmd = new(sql, conn);
            cmd.Parameters.AddWithValue("@StudentID", studentId);

            using SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Subjects.Add(new MySubjectVM
                {
                    SubjectID = reader.GetInt32(0),
                    SubjectCode = reader.GetString(1),
                    SubjectName = reader.GetString(2),
                    Credit = reader.GetInt32(3),
                    RegistrationDate = reader.GetDateTime(4)
                });
            }
        }

        private int GetStudentId()
        {
            int userId = HttpContext.Session.GetInt32("UserID")!.Value;

            using SqlConnection conn = _db.GetConnection();

            using SqlCommand cmd = new(
                "SELECT StudentID FROM Students WHERE UserID = @UserID",
                conn
            );
            cmd.Parameters.AddWithValue("@UserID", userId);

            return (int)cmd.ExecuteScalar();
        }
    }

    public class MySubjectVM
    {
        public int SubjectID { get; set; }
        public string SubjectCode { get; set; }
        public string SubjectName { get; set; }
        public int Credit { get; set; }
        public DateTime RegistrationDate { get; set; }
    }
}
