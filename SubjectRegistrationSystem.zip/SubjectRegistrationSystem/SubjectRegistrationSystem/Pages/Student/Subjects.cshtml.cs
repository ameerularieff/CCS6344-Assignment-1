﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using SubjectRegistrationSystem.Data;
using SubjectRegistrationSystem.Models;

namespace SubjectRegistrationSystem.Pages.Student
{
    public class SubjectsModel : PageModel
    {
        private readonly DbHelper _db;

        public SubjectsModel(DbHelper db)
        {
            _db = db;
        }

        public List<Subject> Subjects { get; set; } = new();

        public void OnGet()
        {
            // Allow only students session
            if (HttpContext.Session.GetString("Role") != "Student")
            {
                Response.Redirect("/Login");
                return;
            }

            int studentId = GetStudentId();

            using SqlConnection conn = _db.GetConnection();

            // Show only subjects NOT yet registered
            string sql = @"
                SELECT SubjectID, SubjectCode, SubjectName, Credit, AvailableSeats
                FROM Subjects
                WHERE SubjectID NOT IN (
                    SELECT SubjectID FROM Registrations WHERE StudentID = @StudentID
                )";

            using SqlCommand cmd = new(sql, conn);
            cmd.Parameters.AddWithValue("@StudentID", studentId);

            using SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Subjects.Add(new Subject
                {
                    SubjectID = reader.GetInt32(0),
                    SubjectCode = reader.GetString(1),
                    SubjectName = reader.GetString(2),
                    Credit = reader.GetInt32(3),
                    AvailableSeats = reader.GetInt32(4)
                });
            }
        }

        public IActionResult OnPost(int subjectId)
        {
            int studentId = GetStudentId();

            using SqlConnection conn = _db.GetConnection();
            using SqlTransaction tran = conn.BeginTransaction();

            try
            {
                // Check seat availability
                using SqlCommand seatCmd = new(
                    "SELECT AvailableSeats FROM Subjects WHERE SubjectID = @SubjectID",
                    conn, tran
                );
                seatCmd.Parameters.AddWithValue("@SubjectID", subjectId);

                int seats = (int)seatCmd.ExecuteScalar();

                if (seats <= 0)
                {
                    TempData["Message"] = "No available seats for this subject.";
                    tran.Rollback();
                    return RedirectToPage();
                }

                // Prevent duplicate registration
                using SqlCommand checkCmd = new(
                    @"SELECT COUNT(*) FROM Registrations
              WHERE StudentID = @StudentID AND SubjectID = @SubjectID",
                    conn, tran
                );
                checkCmd.Parameters.AddWithValue("@StudentID", studentId);
                checkCmd.Parameters.AddWithValue("@SubjectID", subjectId);

                int exists = (int)checkCmd.ExecuteScalar();
                if (exists > 0)
                {
                    TempData["Message"] = "You have already registered this subject.";
                    tran.Rollback();
                    return RedirectToPage();
                }

                // Insert registration
                using SqlCommand insertCmd = new(
                    @"INSERT INTO Registrations (StudentID, SubjectID)
              VALUES (@StudentID, @SubjectID)",
                    conn, tran
                );
                insertCmd.Parameters.AddWithValue("@StudentID", studentId);
                insertCmd.Parameters.AddWithValue("@SubjectID", subjectId);
                insertCmd.ExecuteNonQuery();

                // Decrease available seats
                using SqlCommand updateCmd = new(
                    @"UPDATE Subjects
              SET AvailableSeats = AvailableSeats - 1
              WHERE SubjectID = @SubjectID",
                    conn, tran
                );
                updateCmd.Parameters.AddWithValue("@SubjectID", subjectId);
                updateCmd.ExecuteNonQuery();

                tran.Commit();

                TempData["Message"] = "Subject registered successfully.";
                return RedirectToPage();
            }
            catch
            {
                tran.Rollback();
                throw;
            }
        }

        private int GetStudentId()
        {
            int userId = HttpContext.Session.GetInt32("UserID")!.Value;
            
            using SqlConnection conn = _db.GetConnection();

            using SqlCommand cmd = new(
                "SELECT StudentID FROM Students WHERE UserID = @UserID",
                conn
            );
            cmd.Parameters.AddWithValue("@UserID", userId);

            return (int)cmd.ExecuteScalar();
        }
    }
}