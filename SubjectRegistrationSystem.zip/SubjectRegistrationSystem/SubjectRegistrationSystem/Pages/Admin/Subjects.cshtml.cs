﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using SubjectRegistrationSystem.Data;
using SubjectRegistrationSystem.Models;

namespace SubjectRegistrationSystem.Pages.Admin
{
    public class SubjectsModel : PageModel
    {
        private readonly DbHelper _db;

        public SubjectsModel(DbHelper db)
        {
            _db = db;
        }

        public List<Subject> Subjects { get; set; } = new();

        [BindProperty]
        public Subject NewSubject { get; set; }

        [BindProperty]
        public Subject EditSubject { get; set; }

        public bool IsEditMode => EditSubject != null && EditSubject.SubjectID > 0;

        public void OnGet(int? editId)
        {
            if (HttpContext.Session.GetString("Role") != "Admin")
            {
                Response.Redirect("/Login");
                return;
            }

            LoadSubjects();

            if (editId.HasValue)
            {
                LoadEditSubject(editId.Value);
            }
        }

        public IActionResult OnPostAdd()
        {
            if (HttpContext.Session.GetString("Role") != "Admin")
                return RedirectToPage("/Login");

            using SqlConnection conn = _db.GetConnection();

            using SqlCommand cmd = new(
                @"INSERT INTO Subjects (SubjectCode, SubjectName, Credit, AvailableSeats)
                  VALUES (@Code, @Name, @Credit, @Seats)", conn);

            cmd.Parameters.AddWithValue("@Code", NewSubject.SubjectCode);
            cmd.Parameters.AddWithValue("@Name", NewSubject.SubjectName);
            cmd.Parameters.AddWithValue("@Credit", NewSubject.Credit);
            cmd.Parameters.AddWithValue("@Seats", NewSubject.AvailableSeats);

            cmd.ExecuteNonQuery();

            TempData["Message"] = "Subject added successfully.";
            return RedirectToPage();
        }

        public IActionResult OnPostUpdate()
        {
            if (HttpContext.Session.GetString("Role") != "Admin")
                return RedirectToPage("/Login");

            using SqlConnection conn = _db.GetConnection();

            using SqlCommand cmd = new(
                @"UPDATE Subjects
                  SET SubjectCode = @Code,
                      SubjectName = @Name,
                      Credit = @Credit,
                      AvailableSeats = @Seats
                  WHERE SubjectID = @Id", conn);

            cmd.Parameters.AddWithValue("@Id", EditSubject.SubjectID);
            cmd.Parameters.AddWithValue("@Code", EditSubject.SubjectCode);
            cmd.Parameters.AddWithValue("@Name", EditSubject.SubjectName);
            cmd.Parameters.AddWithValue("@Credit", EditSubject.Credit);
            cmd.Parameters.AddWithValue("@Seats", EditSubject.AvailableSeats);

            cmd.ExecuteNonQuery();

            TempData["Message"] = "Subject updated successfully.";
            return RedirectToPage();
        }

        public IActionResult OnPostDelete(int subjectId)
        {
            if (HttpContext.Session.GetString("Role") != "Admin")
                return RedirectToPage("/Login");

            using SqlConnection conn = _db.GetConnection();

            using SqlTransaction tran = conn.BeginTransaction();

            try
            {
                // Delete related registrations first
                using SqlCommand deleteRegs = new(
                    "DELETE FROM Registrations WHERE SubjectID = @SubjectID",
                    conn, tran
                );
                deleteRegs.Parameters.AddWithValue("@SubjectID", subjectId);
                int affected = deleteRegs.ExecuteNonQuery();

                // Delete subject
                using SqlCommand deleteSubj = new(
                    "DELETE FROM Subjects WHERE SubjectID = @SubjectID",
                    conn, tran
                );
                deleteSubj.Parameters.AddWithValue("@SubjectID", subjectId);
                deleteSubj.ExecuteNonQuery();

                tran.Commit();

                TempData["Message"] =
                    $"Subject deleted successfully. ({affected} registrations removed)";
                return RedirectToPage();
            }
            catch
            {
                tran.Rollback();
                throw;
            }
        }

        private void LoadSubjects()
        {
            Subjects.Clear();

            using SqlConnection conn = _db.GetConnection();

            using SqlCommand cmd = new(
                "SELECT SubjectID, SubjectCode, SubjectName, Credit, AvailableSeats FROM Subjects", conn);

            using SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Subjects.Add(new Subject
                {
                    SubjectID = reader.GetInt32(0),
                    SubjectCode = reader.GetString(1),
                    SubjectName = reader.GetString(2),
                    Credit = reader.GetInt32(3),
                    AvailableSeats = reader.GetInt32(4)
                });
            }
        }

        private void LoadEditSubject(int id)
        {
            using SqlConnection conn = _db.GetConnection();

            using SqlCommand cmd = new(
                "SELECT SubjectID, SubjectCode, SubjectName, Credit, AvailableSeats FROM Subjects WHERE SubjectID = @Id",
                conn);

            cmd.Parameters.AddWithValue("@Id", id);

            using SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                EditSubject = new Subject
                {
                    SubjectID = reader.GetInt32(0),
                    SubjectCode = reader.GetString(1),
                    SubjectName = reader.GetString(2),
                    Credit = reader.GetInt32(3),
                    AvailableSeats = reader.GetInt32(4)
                };
            }
        }
    }
}
