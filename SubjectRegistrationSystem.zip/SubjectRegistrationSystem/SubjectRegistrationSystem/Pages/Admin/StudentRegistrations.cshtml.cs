using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Data.SqlClient;
using SubjectRegistrationSystem.Data;
using SubjectRegistrationSystem.Models;

namespace SubjectRegistrationSystem.Pages.Admin
{
    public class StudentRegistrationsModel : PageModel
    {
        private readonly DbHelper _db;

        public StudentRegistrationsModel(DbHelper db)
        {
            _db = db;
        }

        public List<AdminStudentRegistrationVM> Records { get; set; } = new();

        public void OnGet()
        {
            // Admin only
            if (HttpContext.Session.GetString("Role") != "Admin")
            {
                Response.Redirect("/Login");
                return;
            }

            using SqlConnection conn = _db.GetConnection();

            string sql = @"
                SELECT 
                    st.FullName,
                    st.MatricNo,
                    CONVERT(VARCHAR(20), DecryptByPassPhrase('PhoneKey', st.PhoneNumber)) AS PhoneNumber,
                    s.SubjectCode,
                    s.SubjectName,
                    r.RegistrationDate
                FROM Registrations r
                JOIN Students st ON r.StudentID = st.StudentID
                JOIN Subjects s ON r.SubjectID = s.SubjectID
                ORDER BY st.FullName";

            using SqlCommand cmd = new(sql, conn);
            using SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Records.Add(new AdminStudentRegistrationVM
                {
                    FullName = reader.GetString(0),
                    MatricNo = reader.GetString(1),
                    PhoneNumber = reader.GetString(2),
                    SubjectCode = reader.GetString(3),
                    SubjectName = reader.GetString(4),
                    RegistrationDate = reader.GetDateTime(5)
                });
            }
        }
    }
}
