﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using SubjectRegistrationSystem.Data;
using Microsoft.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

public class LoginModel : PageModel
{
    private readonly DbHelper _db;

    public LoginModel(DbHelper db)
    {
        _db = db;
    }

    [BindProperty]
    public string Username { get; set; }

    [BindProperty]
    public string Password { get; set; }

    public string ErrorMessage { get; set; }

    public void OnPost()
    {
        using SqlConnection conn = _db.GetConnection();

        var cmd = new SqlCommand(
            "SELECT UserID, PasswordHash, Role FROM Users WHERE Username = @username",
            conn
        );
        cmd.Parameters.AddWithValue("@username", Username);

        using var reader = cmd.ExecuteReader();

        if (!reader.Read())
        {
            ErrorMessage = "Invalid username or password";
            return;
        }

        int userId = Convert.ToInt32(reader["UserID"]);
        string role = reader["Role"].ToString();
        byte[] storedHash = (byte[])reader["PasswordHash"];

        using var sha = SHA256.Create();
        var inputHash = sha.ComputeHash(Encoding.UTF8.GetBytes(Password));

        if (!storedHash.SequenceEqual(inputHash))
        {
            ErrorMessage = "Invalid username or password";
            return;
        }

        // Store base session values
        HttpContext.Session.SetInt32("UserID", userId);
        HttpContext.Session.SetString("Role", role);
        HttpContext.Session.SetString("Username", Username);
        HttpContext.Session.SetString("LastActivity", DateTime.UtcNow.ToString("O"));

        reader.Close();

        // IMPORTANT: Fetch StudentID if role is Student
        if (role == "Student")
        {
            var studentCmd = new SqlCommand(
                "SELECT StudentID FROM Students WHERE UserID = @userId",
                conn
            );
            studentCmd.Parameters.AddWithValue("@userId", userId);

            object result = studentCmd.ExecuteScalar();
            if (result != null)
            {
                HttpContext.Session.SetInt32("StudentID", Convert.ToInt32(result));
            }
        }

        Response.Redirect("/Index");
    }
}
