using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SubjectRegistrationSystem.Pages
{
    public class IndexModel : PageModel
    {
        private const int SESSION_TIMEOUT_SECONDS = 15;

        public IActionResult OnGet()
        {
            // User not logged in
            if (HttpContext.Session.GetInt32("UserID") == null)
            {
                return Page(); // show public dashboard
            }

            // Check session expiry
            if (IsSessionExpired())
            {
                HttpContext.Session.Clear();
                TempData["SessionExpired"] = "Your session has expired due to inactivity.";
                return RedirectToPage("/Login");
            }

            // Update last activity timestamp
            HttpContext.Session.SetString(
                "LastActivity",
                DateTime.UtcNow.ToString("O")
            );

            return Page();
        }

        private bool IsSessionExpired()
        {
            var lastActivity = HttpContext.Session.GetString("LastActivity");
            if (lastActivity == null)
                return true;

            var lastTime = DateTime.Parse(lastActivity);
            return (DateTime.UtcNow - lastTime).TotalSeconds > SESSION_TIMEOUT_SECONDS;
        }
    }
}
