-- File: 02_TableCreation.sql
-- Purpose: Create database tables for Subject Registration System
-- DBMS: Microsoft SQL Server

USE SubjectRegistrationDB;
GO

-- =========================
-- USERS TABLE (Login)
-- =========================
CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Username VARCHAR(50) UNIQUE NOT NULL,
    PasswordHash VARBINARY(64) NOT NULL,
    Role VARCHAR(20) NOT NULL CHECK (Role IN ('Student','Admin'))
);

-- =========================
-- STUDENTS TABLE
-- =========================
CREATE TABLE Students (
    StudentID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT UNIQUE NOT NULL,
    MatricNo VARCHAR(20) UNIQUE NOT NULL,
    FullName VARCHAR(100) NOT NULL,
    PhoneNumber VARBINARY(256) NOT NULL,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);

-- =========================
-- SUBJECTS TABLE
-- =========================
CREATE TABLE Subjects (
    SubjectID INT IDENTITY(1,1) PRIMARY KEY,
    SubjectCode VARCHAR(10) UNIQUE NOT NULL,
    SubjectName VARCHAR(100) NOT NULL,
    Credit INT NOT NULL CHECK (Credit > 0),
    AvailableSeats INT NOT NULL CHECK (AvailableSeats >= 0)
);

-- =========================
-- REGISTRATIONS TABLE
-- =========================
CREATE TABLE Registrations (
    RegistrationID INT IDENTITY(1,1) PRIMARY KEY,
    StudentID INT NOT NULL,
    SubjectID INT NOT NULL,
    RegistrationDate DATETIME DEFAULT GETDATE(),
    CONSTRAINT UQ_Student_Subject UNIQUE (StudentID, SubjectID),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (SubjectID) REFERENCES Subjects(SubjectID)
);
GO