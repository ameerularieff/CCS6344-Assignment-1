-- File: 06_CreateRLSFunction.sql
-- Purpose: Row-Level Security logic
-- DBMS: Microsoft SQL Server

CREATE OR ALTER FUNCTION dbo.fn_StudentRLS (@StudentID INT)
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
(
    SELECT 1 AS fn_access
    WHERE
        -- DBA bypass
        IS_MEMBER('db_owner') = 1
        OR
        -- Admin sees every row
        CAST(SESSION_CONTEXT(N'IsAdmin') AS INT) = 1
        OR
        -- Student sees own rows only
        @StudentID = CAST(SESSION_CONTEXT(N'StudentID') AS INT)
);
GO
