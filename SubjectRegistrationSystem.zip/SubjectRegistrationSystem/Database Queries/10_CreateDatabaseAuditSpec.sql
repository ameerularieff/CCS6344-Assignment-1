-- File: 10_CreateDatabaseAuditSpec.sql
-- Purpose: Create database audit specification on query changes
-- DBMS: Microsoft SQL Server

USE SubjectRegistrationDB;
GO

CREATE DATABASE AUDIT SPECIFICATION SR_DatabaseAuditSpec
FOR SERVER AUDIT SR_Server_Audit
ADD (SELECT ON DATABASE::SubjectRegistrationDB BY SR_AppUser),
ADD (INSERT ON DATABASE::SubjectRegistrationDB BY SR_AppUser),
ADD (UPDATE ON DATABASE::SubjectRegistrationDB BY SR_AppUser),
ADD (DELETE ON DATABASE::SubjectRegistrationDB BY SR_AppUser),

ADD (SELECT ON DATABASE::SubjectRegistrationDB BY SR_DBAdmin),
ADD (INSERT ON DATABASE::SubjectRegistrationDB BY SR_DBAdmin),
ADD (UPDATE ON DATABASE::SubjectRegistrationDB BY SR_DBAdmin),
ADD (DELETE ON DATABASE::SubjectRegistrationDB BY SR_DBAdmin)
WITH (STATE = ON);
GO
