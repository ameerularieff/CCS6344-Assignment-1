-- File: 09_CreateServerAuditSpec.sql
-- Purpose: Create server audit specification on login group
-- DBMS: Microsoft SQL Server

USE master;
GO

CREATE SERVER AUDIT SPECIFICATION SR_ServerAuditSpec
FOR SERVER AUDIT SR_Server_Audit
ADD (SUCCESSFUL_LOGIN_GROUP),
ADD (FAILED_LOGIN_GROUP);
GO

ALTER SERVER AUDIT SPECIFICATION SR_ServerAuditSpec
WITH (STATE = ON);
GO
