-- File: 01_CreateDatabase.sql
-- Purpose: Create database
-- DBMS: Microsoft SQL Server

USE master;
GO

CREATE DATABASE SubjectRegistrationDB;
GO