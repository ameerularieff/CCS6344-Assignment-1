-- File: 05_AssignRolesAndPermissions.sql
-- Purpose: Assign users' roles in SubjectRegistrationDB
-- DBMS: Microsoft SQL Server

-- Application user (minimal access)
ALTER ROLE db_datareader ADD MEMBER SR_AppUser;
ALTER ROLE db_datawriter ADD MEMBER SR_AppUser;

-- Database administrator
ALTER ROLE db_owner ADD MEMBER SR_DBAdmin;

-- Auditor (read-only)
ALTER ROLE db_datareader ADD MEMBER SR_Auditor;
GO
