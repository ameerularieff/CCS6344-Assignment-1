-- File: 04_CreateLoginsAndUsers.sql
-- Purpose: Create login in server security and mapping it into SubjectRegistrationDB
-- DBMS: Microsoft SQL Server

USE master;
GO

-- Server-level logins
CREATE LOGIN SR_AppUser WITH PASSWORD = 'StrongApp@123';
CREATE LOGIN SR_DBAdmin WITH PASSWORD = 'StrongDB@123';
CREATE LOGIN SR_Auditor WITH PASSWORD = 'StrongAudit@123';
GO

USE SubjectRegistrationDB;
GO

-- Database users
CREATE USER SR_AppUser FOR LOGIN SR_AppUser;
CREATE USER SR_DBAdmin FOR LOGIN SR_DBAdmin;
CREATE USER SR_Auditor FOR LOGIN SR_Auditor;
GO
