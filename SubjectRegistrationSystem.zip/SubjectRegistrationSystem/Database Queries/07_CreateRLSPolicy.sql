-- File: 07_CreateRLSFunction.sql
-- Purpose: Enforce RLS on data
-- DBMS: Microsoft SQL Server

CREATE SECURITY POLICY StudentRegistrationPolicy
ADD FILTER PREDICATE dbo.fn_StudentRLS(StudentID)
ON dbo.Registrations
WITH (STATE = ON);
GO
