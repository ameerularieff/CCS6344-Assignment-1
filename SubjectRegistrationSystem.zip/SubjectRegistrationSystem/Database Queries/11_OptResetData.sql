-- File: 11_OptResetData.sql
-- Purpose: Resetting data for testing purposes
-- DBMS: Microsoft SQL Server

USE SubjectRegistrationDB;
GO

-- =========================
-- DELETE ROWS
-- =========================
DELETE FROM Registrations;
DELETE FROM Students;
DELETE FROM Subjects;
DELETE FROM Users;

-- =========================
-- RESEEDING UNIQUE KEY COUNTER
-- =========================
DBCC CHECKIDENT ('Registrations', RESEED, 0);
DBCC CHECKIDENT ('Students', RESEED, 0);
DBCC CHECKIDENT ('Subjects', RESEED, 0);
DBCC CHECKIDENT ('Users', RESEED, 0);
GO