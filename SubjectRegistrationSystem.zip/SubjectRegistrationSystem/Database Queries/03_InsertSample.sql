-- File: 03_InsertSample.sql
-- Purpose: Insert sample records for testing and demonstration
-- DBMS: Microsoft SQL Server

USE SubjectRegistrationDB;
GO

-- =========================
-- INSERT USERS
-- =========================

INSERT INTO Users (Username, PasswordHash, Role)
VALUES
('admin', HASHBYTES('SHA2_256', 'admin123'), 'Admin'),
('ameerularieff', HASHBYTES('SHA2_256', 'ameerul123'), 'Student'),
('hakeemhadi', HASHBYTES('SHA2_256', 'hakeem123'), 'Student');

-- =========================
-- INSERT STUDENTS
-- PhoneNumber is encrypted (PII)
-- =========================
INSERT INTO Students (UserID, MatricNo, FullName, PhoneNumber)
VALUES
(2, '1231303379', 'Ameerul Arieff', EncryptByPassPhrase('PhoneKey', '0123456789')),
(3, '1231302918', 'Hakeem Hadi', EncryptByPassPhrase('PhoneKey', '0198765432'));

-- =========================
-- INSERT SUBJECTS
-- =========================
INSERT INTO Subjects (SubjectCode, SubjectName, Credit, AvailableSeats)
VALUES
('CCS101', 'Introduction to Programming', 3, 30),
('CCS202', 'Database Systems', 4, 30),
('CCS303', 'Computer Security', 3, 30);
GO
    