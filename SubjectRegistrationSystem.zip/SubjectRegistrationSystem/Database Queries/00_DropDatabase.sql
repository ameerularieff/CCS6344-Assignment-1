-- File: 00_DropDatabase.sql
-- Purpose: Drop the entire database (Clean reset)
-- DBMS: Microsoft SQL Server

USE master;
GO

DROP DATABASE SubjectRegistrationDB;
GO
