-- File: 08_CreateAudit.sql
-- Purpose: Create server audit
-- DBMS: Microsoft SQL Server

USE master;
GO

CREATE SERVER AUDIT SR_Server_Audit
TO FILE 
(
    FILEPATH = 'C:\MSSQLAudit\',
)
WITH 
(
    QUEUE_DELAY = 1000,
    ON_FAILURE = CONTINUE
);
GO

ALTER SERVER AUDIT SR_Server_Audit 
WITH (STATE = ON);
GO
